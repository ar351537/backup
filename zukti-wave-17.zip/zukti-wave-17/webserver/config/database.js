// config/database.js
module.exports = {
    // monjo db connection
    url: 'mongodb://localhost/passport'
};
