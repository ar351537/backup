import React from 'react';
export default class PerformanceChart extends React.Component {
    constructor(props) {
        super(props);
        this.state={

        }

    }


    render() {
        return(
           <div id="chartsReactEx">

            </div>
        );
    }
}
