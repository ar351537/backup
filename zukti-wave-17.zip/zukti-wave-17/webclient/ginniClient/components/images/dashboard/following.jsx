import React from 'react';

export default class Following extends React.Component {
    constructor(props) {
        super(props);
    }
    render() {
        return(
            <div>
            <h1>Following Segment</h1>
            </div>
        );
    }
}
