module.exports={
  'url':'http://localhost:8080'
}
