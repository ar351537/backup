Steps to  run micro service
1) npm install
2) node user-microservice
