# Angular REST Mongo/MySQL Spring (ARMS) Stack
## Features
1 Spring Boot Cloud Native Distributed Service Architecture
2 Spring REST Services
3 HATEOS REST Services
4 REST API Documentation
5 Spring Data JPA - MySQL and MongoDB
6 Containerized Microservices using Docker

## The App - Movie Cruiser
Movie Cruiser app is decomposed into microservices that are independently deployable applications, organized around certain business capability.

## Part 1
In Part 1, you have a Spring REST API to perform CRUD operations on movies. The application uses the Movie domain object to model a movie. The Service layer has a single implementation that uses a JSON file to return movie list. 

## Steps to run

1. Get repo 

2. Open IDE

3. Select Import Existing Project and import part1_movieapp/pom.xml

4. Run the unit tests

5. Run the project on Tomcat

6. View API documentation of the REST API at http://localhost:8080/swagger-ui.html

7. Use Postman to access the APIs

## Upcoming Part 2

In Part 2, you convert the existing Spring REST API of PART 1 into a HATEOS REST Service

## Upcoming Part 3

In Part 3, you introduce the repository layer to use MONGO DB for performing CRUD Operation. You host the HATEOS REST Service in a Dockerized container

## Upcomming Part 4

In Part 3, you introduce the Gateway Service

## Upcoming Part 5

In Part 3, you introduce the Config Service

## Upcoming Part 6

In Part 3, you introduce the Security Service

