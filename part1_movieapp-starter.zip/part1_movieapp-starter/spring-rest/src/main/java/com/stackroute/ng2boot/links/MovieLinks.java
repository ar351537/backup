package com.stackroute.ng2boot.links;

import java.util.List;

import com.stackroute.ng2boot.domain.Movie;

public interface MovieLinks {
	

	public List<Movie> getallmovielinks(List<Movie> allmovies);
	

	
}
