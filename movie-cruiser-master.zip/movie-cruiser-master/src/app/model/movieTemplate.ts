export class MovieTemplate {
constructor(
public Title: String,
public Year:	String,
public imdbID: String,
public Type: String,
public Poster:	String
) {}
}
