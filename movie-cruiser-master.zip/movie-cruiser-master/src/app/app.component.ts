import { Component , NgModule} from '@angular/core';
import { MdButtonModule, MdCardModule, MdMenuModule, MdToolbarModule, MdIconModule, MdInputModule} from '@angular/material';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.angular.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
constructor() {}
  // movietemplate : movie_template ;
  		// then(movietemplate => this.movietemplate = movietemplate );
}


