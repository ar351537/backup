Code-Assistant

Hello
Steps to be followed before using the bot
-----------------------------------------
1)npm install
2)npm install --no-bin-links
3)npm run serv
