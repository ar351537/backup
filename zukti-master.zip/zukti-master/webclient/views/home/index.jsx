import Home from './home.jsx';

// ES5
// module.exports = Home;
// ES6
export default Home;
