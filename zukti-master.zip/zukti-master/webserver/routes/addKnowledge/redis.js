let redis = require('redis').createClient();
module.exports = redis;
