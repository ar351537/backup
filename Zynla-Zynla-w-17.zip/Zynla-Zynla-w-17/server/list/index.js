module.exports = require('./listdocRouter');
