module.exports = require('./searchrouter');
