import { Component, OnInit } from '@angular/core';
import {MovieService} from '../services/movie.service';
import { Http , Response,RequestOptions,Headers} from '@angular/http';
import {Jsonp} from '@angular/http';

@Component({
  selector: 'app-favcomp',
  templateUrl: './favcomp.component.html',
  styleUrls: ['./favcomp.component.css']
})
export class FavcompComponent implements OnInit {

  constructor(private movieservice:MovieService,private http:Http,private jsonp:Jsonp) { 
  	this.movieservice.printfav().subscribe(res=>{this.favarr=res})}

  ngOnInit() {
  }
  searchString: string;
searchResults:Array<Object>;
totalpages:number;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        
page=1;
genarr=[];
genarr1=[];
favarr=[];
addfav(title,rating,id,poster)
 {
   let obj={id,title,rating,poster};
   console.log(title+""+rating+""+id+""+poster);
   this.movieservice.getfav(obj).subscribe(
(data)=>console.log("added")
);


}

// printthefav(){
//   // return this.http.get("http://localhost:3000/api/bear")
//   //       .map((res:Response) => res.json())
//   //       .do(data => console.log('data: ' + JSON.stringify(data)))
//   //       .subscribe(
//   //           data => { this.favarr=data},
//   //           err => console.error(err),
//   //           () => console.log("favarrayyy"+this.favarr)
//   //       );



// }
res=[];
removefav(id){
  //delete(url: string, options?: RequestOptionsArgs) : Observable<Response>
console.log("In service");
        let url = "http://localhost:3000/api/bear/"+id;
        let encoded_data = id ;
        console.log("id="+id+"url="+url);
        console.log("Stringified");
       let headers = new Headers({ 'Content-Type': 'application/json;charset=utf-8' });
        let options = new RequestOptions({ headers: headers });
// return this.http.delete(url).subscribe((res: any) => {
//       this.persons.splice(this.persons.indexOf(person), 1);
   // });
       return this.http.delete("http://localhost:3000/api/bear/"+id)
       .subscribe((res:any) => this.res =res);
      // .map((res:Response) => res.json());

}
getResults=[];
updateRating(id,title,rating,poster)
{
  let obj={id,title,rating,poster};
  this.movieservice.updateFavourites(obj).subscribe(data => {this.favarr=data});
console.log(this.favarr);

}

}
